package day7;

public class LoopExample {
	public static void main(String[] args) {
		System.out.println("Normal Order");
		for(int i=1;i<=50;i++) {
			System.out.println(i);
		}
		System.out.println();
		System.out.println("Reverse Order");
		for(int i=50;i>=1;i--) {
			System.out.println(i);
		}
		
	}

}
