package day15;

public class MainMethod {
	public static void main(String args[]) {
		Dog d =new Dog();
		Bird b = new Bird();
		System.out.println("dog ");
		d.move();
		d.speak();
		System.out.println("bird");
		b.move();
		b.speak();
		System.out.println(Animal.is_Mammal("dog"));
		System.out.println(Animal.is_Mammal("cat"));
		System.out.println(Animal.category);
	}

}
