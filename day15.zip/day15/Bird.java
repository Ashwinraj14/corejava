package day15;

public class Bird implements Animal{
	public void move() {
		System.out.println("the bird flies in the sky");
	}
	public void speak() {
		System.out.println("the bird says : chirp chirp!");
	}

}
