package day15;

public interface Animal {
	String category = "Living Being";
	static boolean is_Mammal(String animalName) {
		return animalName == "cat" || animalName =="dog" || animalName =="human";
	}
	default void speak() {
		System.out.println("Animal is making a sound");
	}
	
	void move();

}
