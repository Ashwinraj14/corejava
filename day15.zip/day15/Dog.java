package day15;

public class Dog implements Animal {
	public void move() {
		System.out.println("the dog run on four legs");
	}
	public void speak() {
		System.out.println("the dog says woof woof!");
	}

}
