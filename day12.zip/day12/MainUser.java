package day12;

class MainUser {
    public static void main(String args[]) {
        Encapsulation key = new Encapsulation();
        key.setId(11);
        key.setPin(123456789);

        System.out.println("User ID  : " + key.getId());
        System.out.println("User PIN : " + key.getPin());
    }
}

