package day12;

public class Encapsulation {
    private int id;
    private String name;
    private int pin;
    private long account_number;

    // Getters
    public int getId() {
        return id;
    }

    public int getPin() {
        return pin;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }
}
    

