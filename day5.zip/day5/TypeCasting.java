package day5;
import java.util.Scanner;

public class TypeCasting {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Choose the case number:");
        System.out.println("1: byte to short");
        System.out.println("2: short to int");
        System.out.println("3: int to long");
        System.out.println("4: long to float");
        System.out.println("5: float to double");
        System.out.println("6: char to int");
        System.out.println("7: double to float");
        System.out.println("8: float to long");
        System.out.println("9: long to int");
        System.out.println("10: int to short");
        System.out.println("11: short to byte");
        System.out.println("12: int to char");
        System.out.println("13: boolean type");

        int choice = sc.nextInt();

        switch (choice) {
            case 1: {
                System.out.println("enter the value at the range of -128 to 127");
                byte b=sc.nextByte();
                short s = b;
                System.out.println("byte to short: " + s);
                break;
            }
            case 2: {
                 System.out.println("enter the value at the range of -32,768 to 32,767");
                short s=sc.nextShort();
                int i = s;
                System.out.println("short to int: " + i);
                break;
            }
            case 3: {
                System.out.println("enter the value at the range of -2,147,483,648 to 2,147,483,647");
                int i=sc.nextInt();
                long l = i;
                System.out.println("int to long: " + l);
                break;
            }
            case 4: {
                System.out.println("enter the value  at the range of -9,223,372,036,854,775,808  to  9,223,372,036,854,775,807:");
                long l=sc.nextLong(); 
                float f = l;
                System.out.println("long to float: " + f);
                break;
            }
            case 5: {
                System.out.println("enter the value at the range of ±3.4e±38");
                float f=sc.nextFloat(); 
                double d = f;
                System.out.println("float to double: " + d);
                break;
            }
            case 6: {
                System.out.println("enter the character ");
                char c=sc.next().charAt(0);  
                int ci = c;
                System.out.println("char to int: " + ci);
                break;
            }
            case 7: {
                System.out.println("enter the value at the range of ±3.4e±38");
                double d1=sc.nextDouble();
                float f1 = (float) d1;
                System.out.println("double to float: " + f1);
                break;
            }
            case 8: {
                System.out.println("enter the value at the range of ±3.4e±38");
                float f1=sc.nextFloat();
                long l1 = (long) f1;
                System.out.println("float to long: " + l1);
                break;
            }
            case 9: {
                System.out.println("enter the value at the range of -9,223,372,036,854,775,808  to  9,223,372,036,854,775,807:");
                long l1=sc.nextLong();
                int i1 = (int) l1;
                System.out.println("long to int: " + i1);
                break;
            }
            case 10: {
                System.out.println("enter the value at the range of -2,147,483,648 to 2,147,483,647");
                int i1=sc.nextInt();
                short s1 = (short) i1;
                System.out.println("int to short: " + s1);
                break;
            }
            case 11: {
                System.out.println("enter the value at the range of -32,768 to 32,767");
                short s1=sc.nextShort();
                byte b1 = (byte) s1;
                System.out.println("short to byte: " + b1);
                break;
            }
            case 12: {
                System.out.println("enter the value");
                int ci1=sc.nextInt();
                char c1 = (char) ci1;
                System.out.println("int to char: " + c1);
                break;
            }
            case 13: {
                System.out.println("enter the value true or false");
                boolean bool=sc.nextBoolean();
                System.out.println("boolean value: " + bool);
                // Can't cast boolean to/from other types
                break;
            }
            default:
                System.out.println("Invalid choice! Please enter a number between 1 and 13.");
        }

       
    }
}
