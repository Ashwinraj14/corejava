package day11;

import java.util.Scanner;

public class EmployeeOops {
	int id ;
	String name;
	long phoneNumber;
	float salary;
	void display() {
		System.out.println("Employee id :"+id);
		System.out.println("Employee name :"+name);
		System.out.println("Employee PhoneNumber :"+phoneNumber);
		System.out.println("Employee salary :"+salary);
	}

}
