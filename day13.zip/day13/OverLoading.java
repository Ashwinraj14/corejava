package day13;

class OverLoading {
    int add(int a, int b) {
        return a + b;
    }

    int add(int a, int b, int c) {
        return a + b + c;
    }

    float add(float a, float b) {
        return a + b;
    }
}

 class MainUser {
	public static void main(String[] args) {
		OverLoading user = new OverLoading();
		System.out.println("addition of two number :"+user.add(11, 22));
		System.out.println("addition of two float number :"+user.add(11.34f, 22.44f));
		System.out.println("addition of three number :"+user.add(11, 22,93));
		
	}


}