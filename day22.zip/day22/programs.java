package day22;

import java.util.Scanner;

public class programs {

    public static void main(String[] args) {
        floydsTriangle();
        wordFrequencyCount();
        removeDuplicateWords();
        palindromeCheck();
        removeVowels();
        splitByComma();
    }

    // 1. Floyd's Triangle
    public static void floydsTriangle() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the number of rows for Floyd's Triangle:");
        int rows = scan.nextInt();
        System.out.println("Floyd's Triangle:");

        int count = 1;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(count + " ");
                count++;
            }
            System.out.println();
        }
        System.out.println();
    }

    // 2. Word Frequency Counter
    public static void wordFrequencyCount() {
        String input = "Welcome to Java Session Session Session";
        String[] words = input.split(" ");
        int wrc = 1;

        System.out.println("Word Frequency Count:");
        for (int i = 0; i < words.length; i++) {
            if (!words[i].equals("0")) {
                for (int j = i + 1; j < words.length; j++) {
                    if (words[i].equals(words[j])) {
                        wrc++;
                        words[j] = "0";
                    }
                }
                System.out.println(words[i] + " -- " + wrc);
                wrc = 1;
            }
        }
        System.out.println();
    }

    // 3. Remove Duplicate Words
    public static void removeDuplicateWords() {
        String input = "Welcome to Java Session Java Session Session Java";
        String[] words = input.split(" ");

        for (int i = 0; i < words.length; i++) {
            if (words[i] != null) {
                for (int j = i + 1; j < words.length; j++) {
                    if (words[i].equals(words[j])) {
                        words[j] = null;
                    }
                }
            }
        }

        System.out.println("After Removing Duplicates:");
        for (String word : words) {
            if (word != null) {
                System.out.println(word);
            }
        }
        System.out.println();
    }

    // 4. Palindrome Check
    public static void palindromeCheck() {
        String inpStr = "AMMA";
        char[] inpArray = inpStr.toCharArray();
        char[] revArray = new char[inpArray.length];

        int j = 0;
        for (int i = inpArray.length - 1; i >= 0; i--) {
            revArray[j] = inpArray[i];
            j++;
        }

        String revStr = String.valueOf(revArray);

        if (inpStr.equals(revStr)) {
            System.out.println(inpStr + " is a Palindrome.");
        } else {
            System.out.println(inpStr + " is not a Palindrome.");
        }
        System.out.println();
    }

    // 5. Remove Vowels from a String
    public static void removeVowels() {
        String string = "Welcome to Candid Java Programming";
        System.out.println("Original String: " + string);
        string = string.replaceAll("[AEIOUaeiou]", "");
        System.out.println("After Removing Vowels: " + string);
        System.out.println();
    }

    // 6. Split String by Comma
    public static void splitByComma() {
        String input = "Welcome,to,Java Session Session Session";
        String[] words = input.split(",");

        System.out.println("Split by Comma:");
        for (String word : words) {
            System.out.println(word);
        }
        System.out.println();
    }
}
