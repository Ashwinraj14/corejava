package day10;

import java.util.Scanner;

public class EmployeeOops {
	int id ;
	String name;
	long phoneNumber;
	float salary;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeOops emp1 = new EmployeeOops();
		System.out.println("enter the employee id");
		emp1.id=sc.nextInt();
		sc.nextLine();
		System.out.println("enter the employee name ");
		emp1.name=sc.nextLine();
		System.out.println("enter the phone number");
		emp1.phoneNumber=sc.nextLong();
		System.out.println("enter the salary");
		emp1.salary=sc.nextFloat();
		EmployeeOops emp2 = new EmployeeOops();
		emp2.id=2;
		emp2.name="aswin";
		emp2.phoneNumber=1273493045;
		emp2.salary=100000;
		System.out.println("Employee2 id:"+emp2.id);
		System.out.println("Employee2 name:"+emp2.name);
		System.out.println("Employee2 phoneNumber:"+emp2.phoneNumber);
		System.out.println("Employee2 salary:"+emp2.salary);
		EmployeeOops emp3 = new EmployeeOops();
		emp3.id=3;
		emp3.name="raj";
		emp3.phoneNumber=837434783;
		emp3.salary=440000;
		System.out.println("Employee3 id:"+emp3.id);
		System.out.println("Employee3 name:"+emp3.name);
		System.out.println("Employee3 phoneNumber:"+emp3.phoneNumber);
		System.out.println("Employee3 salary:"+emp3.salary);
		EmployeeOops emp4 = new EmployeeOops();
		emp4.id=4;
		emp4.name="gokul";
		emp4.phoneNumber=1319290434;
		emp4.salary=80000;
		System.out.println("Employee4 id:"+emp4.id);
		System.out.println("Employee4 name:"+emp4.name);
		System.out.println("Employee4 phoneNumber:"+emp4.phoneNumber);
		System.out.println("Employee4 salary:"+emp4.salary);
		EmployeeOops emp5 = new EmployeeOops();
		emp5.id=5;
		emp5.name="vignesh";
		emp5.phoneNumber=963742432;
		emp5.salary=90000;
		System.out.println("Employee5 id:"+emp5.id);
		System.out.println("Employee5 name:"+emp5.name);
		System.out.println("Employee5 phoneNumber:"+emp5.phoneNumber);
		System.out.println("Employee5 salary:"+emp5.salary);
	
	}

}
