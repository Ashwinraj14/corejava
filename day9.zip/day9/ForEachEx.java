package day9;

public class ForEachEx {
	public static void main(String[] args) {
		String a[]= {"gok","pradeep","vignesh","kamal"};
		for(int i=0;i<a.length;i++) {
			if(a[i].equals("gok")) {
				a[i]="gokul";
			}
	
		}
		for (String b:a) {
			    	System.out.println(b);
			    }
	}

}
