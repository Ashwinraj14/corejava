package day8;

import java.util.Scanner;

public class ArrayExample {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*String a[]= {"apple","mango","banana"};
		for(int i =0;i<a.length;i++) {
			System.out.println(a[i]);
		}*/
		
		int a[]=new int[4];
		System.out.println("enter the value");
		for(int i=0;i<a.length;i++) {
			
			a[i]=sc.nextInt();
		}
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);;
		}
		
		
	}

}
